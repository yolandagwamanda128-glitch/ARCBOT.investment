"""
ARC bot MT5 ML Bot - starter template
Requirements (Windows, MT5 terminal installed and logged in):
    pip install MetaTrader5 pandas numpy scikit-learn
ALWAYS run on a DEMO account first.
"""
import time
import numpy as np
import pandas as pd
import MetaTrader5 as mt5
from sklearn.ensemble import GradientBoostingClassifier

# ---------------- SETTINGS ----------------
SYMBOL = "EURUSD"
TIMEFRAME = mt5.TIMEFRAME_M15
BARS = 5000
RISK_PER_TRADE = 0.005      # 0.5% of balance per trade
MAX_DAILY_LOSS = 0.03       # stop trading for the day at -3%
MIN_CONFIDENCE = 0.60       # only trade when model is 60%+ sure
SL_ATR, TP_ATR = 1.5, 2.5   # stop/target in ATR multiples
MAGIC = 202611
RETRAIN_EVERY_SEC = 6 * 3600
# ------------------------------------------


def connect():
    if not mt5.initialize():
        raise SystemExit(f"MT5 init failed: {mt5.last_error()}")
    mt5.symbol_select(SYMBOL, True)
    acc = mt5.account_info()
    print(f"Connected: {acc.login} | balance {acc.balance} | demo={acc.trade_mode == 0}")


def get_data(n=BARS):
    rates = mt5.copy_rates_from_pos(SYMBOL, TIMEFRAME, 0, n)
    df = pd.DataFrame(rates)
    df["time"] = pd.to_datetime(df["time"], unit="s")
    return df


def add_features(df):
    d = df.copy()
    d["ret1"] = d["close"].pct_change()
    d["ret5"] = d["close"].pct_change(5)
    d["ret20"] = d["close"].pct_change(20)
    d["sma_ratio"] = d["close"].rolling(10).mean() / d["close"].rolling(50).mean()
    delta = d["close"].diff()
    gain = delta.clip(lower=0).rolling(14).mean()
    loss = (-delta.clip(upper=0)).rolling(14).mean()
    d["rsi"] = 100 - 100 / (1 + gain / (loss + 1e-12))
    tr = pd.concat([d["high"] - d["low"],
                    (d["high"] - d["close"].shift()).abs(),
                    (d["low"] - d["close"].shift()).abs()], axis=1).max(axis=1)
    d["atr"] = tr.rolling(14).mean()
    d["vol"] = d["ret1"].rolling(20).std()
    d["hour"] = d["time"].dt.hour
    return d


FEATURES = ["ret1", "ret5", "ret20", "sma_ratio", "rsi", "vol", "hour"]


def train_model():
    d = add_features(get_data())
    d["target"] = (d["close"].shift(-5) > d["close"]).astype(int)  # up in 5 bars?
    d = d.dropna()
    split = int(len(d) * 0.8)              # time-based split, no shuffling
    train, test = d.iloc[:split], d.iloc[split:-5]
    model = GradientBoostingClassifier(n_estimators=150, max_depth=3, learning_rate=0.05)
    model.fit(train[FEATURES], train["target"])
    acc = (model.predict(test[FEATURES]) == test["target"]).mean()
    print(f"Model trained. Out-of-sample accuracy: {acc:.2%} (needs to be clearly >50%)")
    return model


def daily_loss_hit():
    start = pd.Timestamp.now().normalize().to_pydatetime()
    deals = mt5.history_deals_get(start, pd.Timestamp.now().to_pydatetime())
    pnl = sum(x.profit for x in deals if x.magic == MAGIC) if deals else 0
    return pnl < -MAX_DAILY_LOSS * mt5.account_info().balance


def lot_size(sl_distance):
    info = mt5.symbol_info(SYMBOL)
    risk_money = mt5.account_info().balance * RISK_PER_TRADE
    ticks = sl_distance / info.trade_tick_size
    lots = risk_money / (ticks * info.trade_tick_value)
    step = info.volume_step
    lots = max(info.volume_min, min(info.volume_max, round(lots / step) * step))
    return round(lots, 2)


def has_position():
    pos = mt5.positions_get(symbol=SYMBOL)
    return bool(pos and any(p.magic == MAGIC for p in pos))


def send_order(direction, atr):
    tick = mt5.symbol_info_tick(SYMBOL)
    buy = direction == 1
    price = tick.ask if buy else tick.bid
    sl_d, tp_d = atr * SL_ATR, atr * TP_ATR
    req = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": SYMBOL,
        "volume": lot_size(sl_d),
        "type": mt5.ORDER_TYPE_BUY if buy else mt5.ORDER_TYPE_SELL,
        "price": price,
        "sl": price - sl_d if buy else price + sl_d,
        "tp": price + tp_d if buy else price - tp_d,
        "deviation": 20,
        "magic": MAGIC,
        "comment": "ARC bot ML",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }
    res = mt5.order_send(req)
    print("Order:", "BUY" if buy else "SELL", res.retcode, res.comment)


def run():
    connect()
    model = train_model()
    last_train = time.time()
    last_bar = None
    while True:
        try:
            if time.time() - last_train > RETRAIN_EVERY_SEC:
                model = train_model()
                last_train = time.time()

            d = add_features(get_data(200)).dropna()
            bar_time = d["time"].iloc[-2]          # last CLOSED bar
            if bar_time != last_bar:               # act once per new bar
                last_bar = bar_time
                if daily_loss_hit():
                    print("Daily loss limit hit - no trading today.")
                elif not has_position():
                    row = d.iloc[[-2]]
                    p_up = model.predict_proba(row[FEATURES])[0][1]
                    atr = row["atr"].iloc[0]
                    if p_up >= MIN_CONFIDENCE:
                        send_order(1, atr)
                    elif p_up <= 1 - MIN_CONFIDENCE:
                        send_order(-1, atr)
            time.sleep(10)
        except Exception as e:
            print("Error:", e)
            time.sleep(30)


if __name__ == "__main__":
    run()
