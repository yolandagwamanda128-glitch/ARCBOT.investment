import { Area, AreaChart, ResponsiveContainer, Tooltip, YAxis } from "recharts";
import { formatUsd, type EquityPoint } from "@/lib/robot";

export function EquityChart({ points }: { points: EquityPoint[] }) {
  const values = points.map((p) => p.v);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const pad = Math.max((max - min) * 0.2, 1);
  const up = points[points.length - 1].v >= points[0].v;
  const stroke = up ? "var(--color-up)" : "var(--color-down)";
  return (
    <div className="h-36 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={points} margin={{ top: 8, right: 0, left: 0, bottom: 0 }}>
          <YAxis hide domain={[min - pad, max + pad]} />
          <Tooltip
            cursor={{ stroke: "var(--color-line)" }}
            contentStyle={{
              background: "var(--color-surface)",
              border: "1px solid var(--color-line)",
              borderRadius: 12,
              color: "var(--color-fg)",
              fontSize: 12,
            }}
            formatter={(value) => [formatUsd(Number(value)), "Equity"]}
            labelFormatter={() => "Paper equity"}
          />
          <Area
            type="monotone"
            dataKey="v"
            stroke={stroke}
            fill={stroke}
            fillOpacity={0.16}
            strokeWidth={2}
            dot={false}
            isAnimationActive={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
