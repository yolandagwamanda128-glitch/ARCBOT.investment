import { useEffect, useState, type ReactNode } from "react";
import { Copy, Pause, Play } from "lucide-react";
import { EquityChart } from "@/components/equity-chart";
import {
  DEFAULT_SETTINGS,
  SYMBOLS,
  createSession,
  flatten,
  formatPct,
  formatPrice,
  formatUsd,
  formatWhen,
  robotScript,
  snapshot,
  specOf,
  step,
  type Session,
  type Settings,
  type SymbolId,
} from "@/lib/robot";

const STORAGE_KEY = "arcbot.desk.v1";

type Draft = {
  login: string;
  server: string;
  balance: string;
  symbol: SymbolId;
  liveProfile: boolean;
};

const EMPTY_DRAFT: Draft = {
  login: "",
  server: "",
  balance: "10000",
  symbol: "EURUSD",
  liveProfile: false,
};

function loadSession(): Session | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Session;
    if (!parsed || typeof parsed.login !== "string" || !Array.isArray(parsed.bars) || parsed.bars.length < 52) {
      return null;
    }
    if (!parsed.settings || typeof parsed.cash !== "number") return null;
    return parsed;
  } catch {
    return null;
  }
}

function validate(draft: Draft): string | null {
  if (!/^\d{4,12}$/.test(draft.login.trim())) return "Account number should be 4 to 12 digits.";
  if (draft.server.trim().length < 3) return "Enter the server name shown in MetaTrader.";
  const balance = Number(draft.balance);
  if (!Number.isFinite(balance) || balance < 100 || balance > 1_000_000) {
    return "Use a paper balance between 100 and 1,000,000 USD.";
  }
  return null;
}

export function Desk() {
  const [session, setSession] = useState<Session | null>(null);
  const [hydrated, setHydrated] = useState(false);
  const [draft, setDraft] = useState<Draft>(EMPTY_DRAFT);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [confirmCut, setConfirmCut] = useState(false);

  useEffect(() => {
    setSession(loadSession());
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    if (session) localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
    else localStorage.removeItem(STORAGE_KEY);
  }, [session, hydrated]);

  useEffect(() => {
    if (!session?.armed) return;
    const ms = session.speed === "fast" ? 900 : 3200;
    const id = window.setInterval(() => {
      setSession((current) => (current && current.armed ? step(current) : current));
    }, ms);
    return () => window.clearInterval(id);
  }, [session?.armed, session?.speed]);

  if (!session) {
    return (
      <LinkScreen
        draft={draft}
        error={error}
        onChange={setDraft}
        onSubmit={() => {
          const problem = validate(draft);
          setError(problem);
          if (problem) return;
          const settings: Settings = {
            ...DEFAULT_SETTINGS,
            symbol: draft.symbol,
            liveProfile: draft.liveProfile,
          };
          setSession(
            createSession({
              login: draft.login.trim(),
              server: draft.server.trim(),
              startBalance: Number(draft.balance),
              settings,
            }),
          );
        }}
      />
    );
  }

  return (
    <Terminal
      session={session}
      copied={copied}
      confirmCut={confirmCut}
      onSession={setSession}
      onCopied={setCopied}
      onConfirmCut={setConfirmCut}
      onCut={() => {
        setSession(null);
        setConfirmCut(false);
        setCopied(false);
      }}
    />
  );
}

function LinkScreen({
  draft,
  error,
  onChange,
  onSubmit,
}: {
  draft: Draft;
  error: string | null;
  onChange: (draft: Draft) => void;
  onSubmit: () => void;
}) {
  return (
    <main className="mx-auto min-h-screen w-full max-w-lg px-4 pb-24 pt-6">
      <div className="mb-5 h-1 w-12 rounded-full bg-brand" />
      <p className="text-sm font-bold tracking-tight text-brand">ARC bot</p>
      <h1 className="mt-2 text-3xl font-semibold leading-tight">Link the robot to your MT5 account</h1>
      <p className="mt-3 text-base leading-relaxed text-muted">
        Same rules as your ML bot: it only trades past a 60% score, risks 0.5% a ticket, and stops for the day at a
        3% loss. This desk runs that robot on a paper book under your account number.
      </p>

      <form
        className="mt-6 rounded-xl border border-line bg-surface p-4"
        onSubmit={(event) => {
          event.preventDefault();
          onSubmit();
        }}
      >
        <Field label="Account number">
          <input
            inputMode="numeric"
            autoComplete="off"
            placeholder="50123478"
            value={draft.login}
            onChange={(event) => onChange({ ...draft, login: event.target.value.replace(/\D/g, "").slice(0, 12) })}
            className="h-12 w-full rounded-lg border border-line bg-bg px-3 font-mono text-base text-fg"
          />
        </Field>
        <Field label="Server">
          <input
            autoComplete="off"
            placeholder="BrokerName-Demo"
            value={draft.server}
            onChange={(event) => onChange({ ...draft, server: event.target.value })}
            className="h-12 w-full rounded-lg border border-line bg-bg px-3 text-base text-fg"
          />
        </Field>
        <Field label="Paper balance (USD)">
          <input
            inputMode="decimal"
            value={draft.balance}
            onChange={(event) => onChange({ ...draft, balance: event.target.value })}
            className="h-12 w-full rounded-lg border border-line bg-bg px-3 font-mono text-base text-fg"
          />
        </Field>

        <p className="mb-2 mt-4 text-sm text-muted">Symbol</p>
        <div className="grid grid-cols-2 gap-2">
          {SYMBOLS.map((item) => {
            const on = draft.symbol === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onChange({ ...draft, symbol: item.id })}
                className={
                  on
                    ? "h-14 rounded-lg bg-brand px-3 text-left text-brand-ink"
                    : "h-14 rounded-lg border border-line bg-raised px-3 text-left text-fg"
                }
              >
                <span className="block font-mono text-sm font-medium">{item.id}</span>
                <span className={on ? "block text-xs text-brand-ink" : "block text-xs text-muted"}>{item.label}</span>
              </button>
            );
          })}
        </div>

        <label className="mt-4 flex items-start gap-3 rounded-lg border border-line bg-bg px-3 py-3">
          <input
            type="checkbox"
            checked={draft.liveProfile}
            onChange={(event) => onChange({ ...draft, liveProfile: event.target.checked })}
            className="mt-1 size-5 accent-brand"
          />
          <span>
            <span className="block text-sm font-medium">This is a live account</span>
            <span className="mt-1 block text-sm leading-relaxed text-muted">
              Leave this off for a demo. The desk still paper-trades either way. The Windows script will refuse a
              real account unless you tick this.
            </span>
          </span>
        </label>

        {error ? <p className="mt-3 text-sm text-down">{error}</p> : null}

        <button type="submit" className="mt-4 h-12 w-full rounded-xl bg-brand text-base font-semibold text-brand-ink">
          Arm the robot
        </button>
        <p className="mt-3 text-sm leading-relaxed text-muted">
          Your password stays inside MetaTrader. This screen never asks for it, and it cannot place tickets at the
          broker. Orders you watch here are paper fills on a simulated tape.
        </p>
      </form>
    </main>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="mb-3 block">
      <span className="mb-1 block text-sm text-muted">{label}</span>
      {children}
    </label>
  );
}

function Terminal({
  session,
  copied,
  confirmCut,
  onSession,
  onCopied,
  onConfirmCut,
  onCut,
}: {
  session: Session;
  copied: boolean;
  confirmCut: boolean;
  onSession: (update: Session | ((current: Session | null) => Session | null)) => void;
  onCopied: (value: boolean) => void;
  onConfirmCut: (value: boolean) => void;
  onCut: () => void;
}) {
  const view = snapshot(session);
  const { spec, last, pUp, floating, equity, wins, locked, call } = view;
  const dayLimit = -session.settings.maxDailyLoss * session.cash;
  const winRate = session.trades.length ? wins / session.trades.length : 0;
  const callLabel = call === "buy" ? "Buy" : call === "sell" ? "Sell" : call === "halt" ? "Halted" : "Wait";
  const callClass = call === "buy" ? "text-up" : call === "sell" || call === "halt" ? "text-down" : "text-muted";

  function patch(recipe: (current: Session) => Session) {
    onSession((current) => (current ? recipe(current) : current));
  }

  return (
    <main className="mx-auto min-h-screen w-full max-w-5xl px-4 pb-24 pt-4">
      <header className="flex items-start justify-between gap-3 border-b border-line pb-4">
        <div>
          <p className="text-sm font-bold tracking-tight text-brand">ARC bot</p>
          <h1 className="mt-1 break-words text-xl font-semibold">
            {session.login}
            <span className="text-muted"> · </span>
            <span className="font-normal text-muted">{session.server}</span>
          </h1>
          <p className="mt-1 text-sm text-muted">
            {session.settings.liveProfile ? "Live profile" : "Demo profile"} · paper book · not logged into the
            terminal
          </p>
        </div>
        <span
          className={
            session.armed
              ? "mt-1 shrink-0 rounded-full bg-brand px-3 py-2 font-mono text-xs text-brand-ink"
              : "mt-1 shrink-0 rounded-full border border-line px-3 py-2 font-mono text-xs text-muted"
          }
        >
          {session.armed ? "ARMED" : "PAUSED"}
        </span>
      </header>

      <section className="mt-4 grid gap-3 lg:grid-cols-[1.4fr_0.8fr]">
        <div className="rounded-xl border border-line bg-surface p-4">
          <div className="flex items-end justify-between gap-3">
            <div>
              <p className="font-mono text-xs text-muted">{spec.id} · simulated M15 tape</p>
              <p className="mt-1 font-mono text-3xl font-medium tabular-nums">{formatPrice(last.c, spec.digits)}</p>
              <p className="mt-1 text-sm text-muted">{formatWhen(last.t)} SAST</p>
            </div>
            <div className="text-right">
              <p className="font-mono text-xs text-muted">Signal</p>
              <p className={`font-mono text-3xl font-medium ${callClass}`}>{callLabel}</p>
              <p className="mt-1 font-mono text-sm tabular-nums text-muted">score {formatPct(pUp)}</p>
            </div>
          </div>
          <Confidence pUp={pUp} min={session.settings.minConfidence} />
          <p className="mt-2 text-sm text-muted">
            Buys at or above {formatPct(session.settings.minConfidence)}. Sells at or below{" "}
            {formatPct(1 - session.settings.minConfidence)}. One ticket at a time.
          </p>
          {locked ? (
            <p className="mt-3 rounded-lg bg-bg px-3 py-2 text-sm text-down">
              Day halt is on. The robot will not open a new ticket until the next Johannesburg session.
            </p>
          ) : null}
        </div>

        <div className="grid gap-2">
          <Stat label="Equity" value={formatUsd(equity)} hint={`from ${formatUsd(session.startBalance)}`} />
          <Stat
            label="Today"
            value={formatUsd(session.dayRealized)}
            hint={`halt ${formatUsd(dayLimit)}`}
            tone={session.dayRealized < 0 ? "down" : session.dayRealized > 0 ? "up" : "flat"}
          />
          <Stat
            label="Closed"
            value={`${wins}/${session.trades.length}`}
            hint={session.trades.length ? `${formatPct(winRate)} wins` : "no fills yet"}
          />
        </div>
      </section>

      <section className="mt-3 rounded-xl border border-line bg-surface p-4">
        {session.position ? (
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="text-sm text-muted">Open ticket</p>
              <p className="mt-1 font-mono text-lg">
                {session.position.side === "buy" ? "Buy" : "Sell"} {session.position.lots.toFixed(2)}
              </p>
              <p className="mt-1 font-mono text-sm text-muted">
                in {formatPrice(session.position.entry, spec.digits)} · stop{" "}
                {formatPrice(session.position.sl, spec.digits)} · target {formatPrice(session.position.tp, spec.digits)}
              </p>
            </div>
            <p className={`font-mono text-xl tabular-nums ${floating >= 0 ? "text-up" : "text-down"}`}>
              {formatUsd(floating)}
            </p>
          </div>
        ) : (
          <div>
            <p className="text-sm text-muted">Open ticket</p>
            <p className="mt-1 text-base">Flat. Waiting for a bar outside the no-trade band.</p>
          </div>
        )}
        <div className="mt-4 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => patch((current) => ({ ...current, armed: !current.armed }))}
            className="inline-flex h-11 items-center gap-2 rounded-xl bg-brand px-4 font-semibold text-brand-ink"
          >
            {session.armed ? <Pause className="size-4" /> : <Play className="size-4" />}
            {session.armed ? "Pause" : "Arm"}
          </button>
          <button
            type="button"
            disabled={!session.position}
            onClick={() => patch((current) => flatten(current))}
            className="h-11 rounded-xl border border-line bg-raised px-4 font-medium text-fg disabled:opacity-40"
          >
            Flatten
          </button>
          <button
            type="button"
            onClick={() => patch((current) => ({ ...current, speed: current.speed === "fast" ? "desk" : "fast" }))}
            className="h-11 rounded-xl border border-line bg-raised px-4 font-medium text-fg"
          >
            {session.speed === "fast" ? "Fast tape" : "Slow tape"}
          </button>
        </div>
      </section>

      <section className="mt-3 rounded-xl border border-line bg-surface p-4">
        <div className="mb-2 flex items-baseline justify-between">
          <h2 className="text-base font-semibold">Paper equity</h2>
          <p className="text-sm text-muted">Includes the open ticket</p>
        </div>
        <EquityChart points={session.equityPoints} />
      </section>

      <section className="mt-3 grid gap-3 lg:grid-cols-2">
        <div className="rounded-xl border border-line bg-surface p-4">
          <h2 className="text-base font-semibold">Fills</h2>
          {session.trades.length === 0 ? (
            <p className="mt-3 text-sm text-muted">No closed tickets yet. Stops and targets print here.</p>
          ) : (
            <ul className="mt-3 divide-y divide-line">
              {session.trades.slice(0, 8).map((trade) => (
                <li key={trade.id} className="flex items-center justify-between gap-3 py-3">
                  <div>
                    <p className="font-mono text-sm">
                      {trade.side === "buy" ? "Buy" : "Sell"} {trade.lots.toFixed(2)}
                      <span className="text-muted">
                        {" "}
                        · {trade.reason === "tp" ? "target" : trade.reason === "sl" ? "stop" : "flat"}
                      </span>
                    </p>
                    <p className="text-sm text-muted">{formatWhen(trade.closedAt)}</p>
                  </div>
                  <p className={`font-mono tabular-nums ${trade.pnl >= 0 ? "text-up" : "text-down"}`}>
                    {formatUsd(trade.pnl)}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="rounded-xl border border-line bg-surface p-4">
          <h2 className="text-base font-semibold">Robot log</h2>
          <ul className="mt-3 space-y-3">
            {session.notes.map((note) => (
              <li key={note.id} className="text-sm leading-relaxed">
                <span className="mr-2 font-mono text-xs text-muted">{formatWhen(note.t)}</span>
                {note.text}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <Rules
        session={session}
        onChange={(settings) => patch((current) => ({ ...current, settings }))}
        onSymbol={(symbol) =>
          patch((current) =>
            createSession({
              login: current.login,
              server: current.server,
              startBalance: current.startBalance,
              settings: { ...current.settings, symbol },
              speed: current.speed,
            }),
          )
        }
      />

      <section className="mt-3 rounded-xl border border-line bg-surface p-4">
        <h2 className="text-base font-semibold">Send orders into MetaTrader</h2>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          MetaTrader only accepts tickets from the terminal on a Windows computer that is already logged into{" "}
          {session.login}. The script below is your robot with these rules filled in. It checks the account number
          and will not trade a live account unless you opted in. The password is never in the script.
        </p>
        <button
          type="button"
          onClick={() => {
            void navigator.clipboard.writeText(robotScript(session)).then(
              () => onCopied(true),
              () => onCopied(false),
            );
          }}
          className="mt-3 inline-flex h-11 items-center gap-2 rounded-xl border border-line bg-raised px-4 font-medium"
        >
          <Copy className="size-4" />
          {copied ? "Copied" : "Copy robot script"}
        </button>
        <details className="mt-3">
          <summary className="text-sm text-brand">Show the script</summary>
          <pre className="mt-3 max-h-64 overflow-auto rounded-lg bg-bg p-3 font-mono text-xs leading-relaxed text-muted">
            {robotScript(session)}
          </pre>
        </details>
      </section>

      <div className="mt-4">
        {confirmCut ? (
          <div className="flex flex-wrap items-center gap-2">
            <p className="text-sm text-muted">Remove this paper link from the device?</p>
            <button type="button" onClick={onCut} className="h-11 rounded-xl bg-down px-4 font-semibold text-bg">
              Remove
            </button>
            <button
              type="button"
              onClick={() => onConfirmCut(false)}
              className="h-11 rounded-xl border border-line px-4 font-medium"
            >
              Keep
            </button>
          </div>
        ) : (
          <button type="button" onClick={() => onConfirmCut(true)} className="h-11 text-sm text-muted">
            Remove account link
          </button>
        )}
      </div>
    </main>
  );
}

function Confidence({ pUp, min }: { pUp: number; min: number }) {
  const band = (1 - min) * 100;
  return (
    <div className="relative mt-4 h-3 rounded-full bg-raised">
      <div className="absolute inset-y-0 left-0 rounded-l-full bg-down/40" style={{ width: `${band}%` }} />
      <div className="absolute inset-y-0 right-0 rounded-r-full bg-up/40" style={{ width: `${band}%` }} />
      <div
        className="absolute top-1/2 h-5 w-1 -translate-x-1/2 -translate-y-1/2 rounded-full bg-fg"
        style={{ left: `${Math.min(100, Math.max(0, pUp * 100))}%` }}
      />
    </div>
  );
}

function Stat({
  label,
  value,
  hint,
  tone = "flat",
}: {
  label: string;
  value: string;
  hint: string;
  tone?: "up" | "down" | "flat";
}) {
  const toneClass = tone === "up" ? "text-up" : tone === "down" ? "text-down" : "text-fg";
  return (
    <div className="rounded-xl border border-line bg-surface px-3 py-3">
      <div className="flex items-baseline justify-between gap-3">
        <p className="text-sm text-muted">{label}</p>
        <p className={`font-mono text-lg tabular-nums ${toneClass}`}>{value}</p>
      </div>
      <p className="mt-1 text-xs text-muted">{hint}</p>
    </div>
  );
}

function Rules({
  session,
  onChange,
  onSymbol,
}: {
  session: Session;
  onChange: (settings: Settings) => void;
  onSymbol: (symbol: SymbolId) => void;
}) {
  const s = session.settings;
  return (
    <section className="mt-3 rounded-xl border border-line bg-surface p-4">
      <h2 className="text-base font-semibold">Risk rules</h2>
      <p className="mt-1 text-sm text-muted">
        {formatPct(s.risk)} risk · score {formatPct(s.minConfidence)} · {s.slAtr.toFixed(1)} / {s.tpAtr.toFixed(1)}{" "}
        ATR · day halt {formatPct(s.maxDailyLoss)}
      </p>
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <Slider
          label="Risk per ticket"
          value={s.risk}
          min={0.002}
          max={0.02}
          step={0.001}
          display={formatPct(s.risk)}
          onChange={(risk) => onChange({ ...s, risk })}
        />
        <Slider
          label="Day halt"
          value={s.maxDailyLoss}
          min={0.01}
          max={0.08}
          step={0.005}
          display={formatPct(s.maxDailyLoss)}
          onChange={(maxDailyLoss) => onChange({ ...s, maxDailyLoss })}
        />
        <Slider
          label="Minimum score"
          value={s.minConfidence}
          min={0.55}
          max={0.75}
          step={0.01}
          display={formatPct(s.minConfidence)}
          onChange={(minConfidence) => onChange({ ...s, minConfidence })}
        />
        <Slider
          label="Stop in ATR"
          value={s.slAtr}
          min={1}
          max={3}
          step={0.1}
          display={`${s.slAtr.toFixed(1)} / ${s.tpAtr.toFixed(1)} target`}
          onChange={(slAtr) => onChange({ ...s, slAtr, tpAtr: Math.max(Number((slAtr + 1).toFixed(1)), s.tpAtr) })}
        />
      </div>
      <p className="mb-2 mt-4 text-sm text-muted">Pair · switching starts a fresh paper book</p>
      <div className="flex flex-wrap gap-2">
        {SYMBOLS.map((item) => {
          const on = item.id === s.symbol;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSymbol(item.id)}
              className={
                on
                  ? "h-11 rounded-lg bg-brand px-3 font-mono text-sm text-brand-ink"
                  : "h-11 rounded-lg border border-line bg-raised px-3 font-mono text-sm"
              }
            >
              {item.id}
            </button>
          );
        })}
      </div>
      <p className="mt-3 text-sm text-muted">
        Open stops stay where they were filled. New tickets use the sliders. Tape price is simulated from{" "}
        {specOf(s.symbol).label}, not a broker feed.
      </p>
    </section>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  step,
  display,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  display: string;
  onChange: (value: number) => void;
}) {
  return (
    <label className="block">
      <span className="flex items-baseline justify-between gap-3 text-sm">
        <span className="text-muted">{label}</span>
        <span className="font-mono tabular-nums">{display}</span>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
        className="mt-2 w-full accent-brand"
      />
    </label>
  );
}
