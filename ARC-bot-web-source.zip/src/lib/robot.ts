export type SymbolId = "EURUSD" | "GBPUSD" | "USDZAR" | "XAUUSD";
export type Side = "buy" | "sell";
export type Speed = "desk" | "fast";
export type ExitReason = "tp" | "sl" | "flat";

export type Bar = { t: number; o: number; h: number; l: number; c: number };

export type Position = {
  side: Side;
  lots: number;
  entry: number;
  sl: number;
  tp: number;
  openedAt: number;
};

export type Trade = {
  id: number;
  side: Side;
  lots: number;
  entry: number;
  exit: number;
  pnl: number;
  reason: ExitReason;
  closedAt: number;
};

export type Note = { id: number; t: number; text: string };

export type EquityPoint = { t: number; v: number };

export type Settings = {
  symbol: SymbolId;
  risk: number;
  maxDailyLoss: number;
  minConfidence: number;
  slAtr: number;
  tpAtr: number;
  liveProfile: boolean;
};

export type Session = {
  login: string;
  server: string;
  startBalance: number;
  settings: Settings;
  armed: boolean;
  speed: Speed;
  rng: number;
  bars: Bar[];
  cash: number;
  position: Position | null;
  trades: Trade[];
  dayKey: string;
  dayRealized: number;
  haltNoted: boolean;
  notes: Note[];
  equityPoints: EquityPoint[];
  nextId: number;
};

export type SymbolSpec = {
  id: SymbolId;
  label: string;
  digits: number;
  tickSize: number;
  tickValue: number;
  start: number;
  vol: number;
  spread: number;
};

export const SYMBOLS: SymbolSpec[] = [
  {
    id: "EURUSD",
    label: "Euro / Dollar",
    digits: 5,
    tickSize: 0.00001,
    tickValue: 1,
    start: 1.0864,
    vol: 0.00028,
    spread: 0.00012,
  },
  {
    id: "GBPUSD",
    label: "Sterling / Dollar",
    digits: 5,
    tickSize: 0.00001,
    tickValue: 1,
    start: 1.2712,
    vol: 0.00036,
    spread: 0.00014,
  },
  {
    id: "USDZAR",
    label: "Dollar / Rand",
    digits: 5,
    tickSize: 0.00001,
    tickValue: 0.055,
    start: 17.842,
    vol: 0.014,
    spread: 0.0018,
  },
  {
    id: "XAUUSD",
    label: "Gold",
    digits: 2,
    tickSize: 0.01,
    tickValue: 1,
    start: 2648.3,
    vol: 1.85,
    spread: 0.28,
  },
];

export const DEFAULT_SETTINGS: Settings = {
  symbol: "EURUSD",
  risk: 0.005,
  maxDailyLoss: 0.03,
  minConfidence: 0.6,
  slAtr: 1.5,
  tpAtr: 2.5,
  liveProfile: false,
};

const BAR_MS = 15 * 60 * 1000;
const QUIET_BARS = 80;
const REPLAY_BARS = 90;

export function specOf(id: SymbolId): SymbolSpec {
  const spec = SYMBOLS.find((s) => s.id === id);
  if (!spec) return SYMBOLS[0];
  return spec;
}

function mulberry(seed: number) {
  let a = seed >>> 0;
  return {
    next() {
      a |= 0;
      a = (a + 0x6d2b79f5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    },
    state() {
      return a >>> 0;
    },
  };
}

function gauss(rng: { next(): number }) {
  let u = 0;
  let v = 0;
  while (u === 0) u = rng.next();
  while (v === 0) v = rng.next();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(Math.PI * 2 * v);
}

function roundPx(value: number, digits: number) {
  const f = 10 ** digits;
  return Math.round(value * f) / f;
}

function roundLots(value: number) {
  return Math.round(value * 100) / 100;
}

export function dayKeyOf(t: number) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Africa/Johannesburg",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(t);
}

export function formatWhen(t: number) {
  return new Intl.DateTimeFormat("en-ZA", {
    timeZone: "Africa/Johannesburg",
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).format(t);
}

export function formatPrice(n: number, digits: number) {
  return n.toFixed(digits);
}

export function formatUsd(n: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 2,
  }).format(n);
}

export function formatPct(n: number) {
  return `${Math.round(n * 100)}%`;
}

type Feat = {
  ret1: number;
  ret5: number;
  ret20: number;
  smaRatio: number;
  rsi: number;
  atr: number;
  vol: number;
  hour: number;
};

function mean(xs: number[]) {
  let s = 0;
  for (const x of xs) s += x;
  return s / xs.length;
}

function stdev(xs: number[]) {
  if (xs.length < 2) return 0;
  const m = mean(xs);
  let v = 0;
  for (const x of xs) v += (x - m) ** 2;
  return Math.sqrt(v / (xs.length - 1));
}

function features(bars: Bar[]): Feat | null {
  if (bars.length < 52) return null;
  const closes = bars.map((b) => b.c);
  const last = closes.length - 1;
  const ret = (n: number) => (closes[last] - closes[last - n]) / closes[last - n];
  const sma = (n: number) => mean(closes.slice(last - n + 1, last + 1));
  const deltas: number[] = [];
  for (let i = last - 13; i <= last; i++) deltas.push(closes[i] - closes[i - 1]);
  const gain = mean(deltas.map((d) => (d > 0 ? d : 0)));
  const loss = mean(deltas.map((d) => (d < 0 ? -d : 0)));
  const rsi = 100 - 100 / (1 + gain / (loss + 1e-12));
  const trs: number[] = [];
  for (let i = last - 13; i <= last; i++) {
    const prevC = closes[i - 1];
    const b = bars[i];
    trs.push(Math.max(b.h - b.l, Math.abs(b.h - prevC), Math.abs(b.l - prevC)));
  }
  const rets: number[] = [];
  for (let i = last - 19; i <= last; i++) rets.push((closes[i] - closes[i - 1]) / closes[i - 1]);
  return {
    ret1: ret(1),
    ret5: ret(5),
    ret20: ret(20),
    smaRatio: sma(10) / sma(50),
    rsi,
    atr: mean(trs),
    vol: stdev(rets),
    hour: new Date(bars[last].t).getUTCHours(),
  };
}

/** Desk score from the same features the Windows model is trained on. */
export function probability(f: Feat) {
  const mom = Math.tanh(f.ret5 / (f.vol * Math.sqrt(5) + 1e-8));
  const trend = Math.tanh((f.smaRatio - 1) / 0.004);
  const rsiTilt = (f.rsi - 50) / 55;
  const fade = f.rsi > 78 ? -0.45 : f.rsi < 22 ? 0.45 : 0;
  const session = f.hour >= 7 && f.hour <= 16 ? 0.06 : -0.04;
  const logit = 1.05 * mom + 0.72 * trend + 0.22 * rsiTilt + fade + session;
  return 1 / (1 + Math.exp(-logit));
}

function pnlAt(pos: Position, price: number, spec: SymbolSpec) {
  const diff = pos.side === "buy" ? price - pos.entry : pos.entry - price;
  const ticks = diff / spec.tickSize;
  return ticks * spec.tickValue * pos.lots;
}

function lotSize(cash: number, slDistance: number, spec: SymbolSpec, risk: number) {
  const riskMoney = Math.max(cash, 0) * risk;
  const ticks = slDistance / spec.tickSize;
  if (!(ticks > 0) || !(spec.tickValue > 0)) return 0.01;
  let lots = riskMoney / (ticks * spec.tickValue);
  lots = roundLots(Math.round(lots / 0.01) * 0.01);
  if (lots < 0.01) lots = 0.01;
  if (lots > 50) lots = 50;
  return lots;
}

function pushNote(session: Session, t: number, text: string): Note[] {
  return [{ id: session.nextId, t, text }, ...session.notes].slice(0, 12);
}

function nextBar(prev: Bar, spec: SymbolSpec, rng: { next(): number }, t: number): Bar {
  const hour = new Date(t).getUTCHours();
  const sessionBoost = hour >= 7 && hour <= 16 ? 1.12 : 0.72;
  const pull = (spec.start - prev.c) * 0.02;
  const shock = gauss(rng) * spec.vol * sessionBoost;
  const c = roundPx(Math.max(prev.c + pull + shock, spec.tickSize * 10), spec.digits);
  const o = prev.c;
  const wick = Math.abs(gauss(rng)) * spec.vol * 0.55 * sessionBoost;
  const h = roundPx(Math.max(o, c) + wick, spec.digits);
  const l = roundPx(Math.min(o, c) - wick, spec.digits);
  return { t, o, h, l, c };
}

function markEquity(session: Session, spec: SymbolSpec): number {
  const last = session.bars[session.bars.length - 1];
  const floating = session.position ? pnlAt(session.position, last.c, spec) : 0;
  return session.cash + floating;
}

function closeAt(session: Session, exit: number, reason: ExitReason, t: number, spec: SymbolSpec): Session {
  const pos = session.position;
  if (!pos) return session;
  const px = roundPx(exit, spec.digits);
  const pnl = pnlAt(pos, px, spec);
  const verb = reason === "tp" ? "Target filled" : reason === "sl" ? "Stop filled" : "Flattened";
  return {
    ...session,
    cash: session.cash + pnl,
    position: null,
    dayRealized: session.dayRealized + pnl,
    trades: [
      {
        id: session.nextId,
        side: pos.side,
        lots: pos.lots,
        entry: pos.entry,
        exit: px,
        pnl,
        reason,
        closedAt: t,
      },
      ...session.trades,
    ].slice(0, 40),
    notes: pushNote(session, t, `${verb} · ${formatUsd(pnl)}`),
    nextId: session.nextId + 1,
  };
}

function tryEntry(session: Session, bar: Bar, spec: SymbolSpec): Session {
  const feat = features(session.bars);
  if (!feat) return session;
  const pUp = probability(feat);
  const { minConfidence, slAtr, tpAtr, risk } = session.settings;
  const locked = session.dayRealized < -session.settings.maxDailyLoss * session.cash;
  if (locked) {
    if (session.haltNoted) return session;
    return {
      ...session,
      haltNoted: true,
      notes: pushNote(
        session,
        bar.t,
        `Day halt. Realized loss passed ${formatPct(session.settings.maxDailyLoss)} of balance.`,
      ),
      nextId: session.nextId + 1,
    };
  }
  const buy = pUp >= minConfidence;
  const sell = pUp <= 1 - minConfidence;
  if (!buy && !sell) return session;
  const side: Side = buy ? "buy" : "sell";
  const slD = Math.max(feat.atr * slAtr, spec.tickSize * 30);
  const tpD = Math.max(feat.atr * tpAtr, spec.tickSize * 30);
  const entry = roundPx(side === "buy" ? bar.c + spec.spread / 2 : bar.c - spec.spread / 2, spec.digits);
  const sl = roundPx(side === "buy" ? entry - slD : entry + slD, spec.digits);
  const tp = roundPx(side === "buy" ? entry + tpD : entry - tpD, spec.digits);
  const lots = lotSize(session.cash, slD, spec, risk);
  return {
    ...session,
    position: { side, lots, entry, sl, tp, openedAt: bar.t },
    notes: pushNote(
      session,
      bar.t,
      `${side === "buy" ? "Buy" : "Sell"} ${lots.toFixed(2)} · score ${formatPct(pUp)} · stop ${formatPrice(sl, spec.digits)}`,
    ),
    nextId: session.nextId + 1,
  };
}

function rollDay(session: Session, t: number): Session {
  const key = dayKeyOf(t);
  if (key === session.dayKey) return session;
  return { ...session, dayKey: key, dayRealized: 0, haltNoted: false };
}

function appendPoint(session: Session, spec: SymbolSpec): Session {
  const last = session.bars[session.bars.length - 1];
  return {
    ...session,
    equityPoints: [...session.equityPoints, { t: last.t, v: markEquity(session, spec) }].slice(-220),
  };
}

export function step(session: Session): Session {
  const spec = specOf(session.settings.symbol);
  const rng = mulberry(session.rng);
  const prev = session.bars[session.bars.length - 1];
  const bar = nextBar(prev, spec, rng, prev.t + BAR_MS);
  let next: Session = rollDay({ ...session, rng: rng.state(), bars: [...session.bars, bar].slice(-360) }, bar.t);
  if (next.position) {
    const pos = next.position;
    const hitSl = pos.side === "buy" ? bar.l <= pos.sl : bar.h >= pos.sl;
    const hitTp = pos.side === "buy" ? bar.h >= pos.tp : bar.l <= pos.tp;
    if (hitSl || hitTp) {
      let reason: ExitReason = hitSl ? "sl" : "tp";
      let price = reason === "sl" ? pos.sl : pos.tp;
      if (hitSl && hitTp) {
        if (Math.abs(bar.o - pos.sl) <= Math.abs(bar.o - pos.tp)) {
          reason = "sl";
          price = pos.sl;
        } else {
          reason = "tp";
          price = pos.tp;
        }
      }
      next = closeAt(next, price, reason, bar.t, spec);
    }
  }
  if (!next.position) next = tryEntry(next, bar, spec);
  return appendPoint(next, spec);
}

function quiet(session: Session): Session {
  const spec = specOf(session.settings.symbol);
  const rng = mulberry(session.rng);
  const prev = session.bars[session.bars.length - 1];
  const bar = nextBar(prev, spec, rng, prev.t + BAR_MS);
  return appendPoint(rollDay({ ...session, rng: rng.state(), bars: [...session.bars, bar].slice(-360) }, bar.t), spec);
}

export function createSession(input: {
  login: string;
  server: string;
  startBalance: number;
  settings: Settings;
  speed?: Speed;
}): Session {
  const spec = specOf(input.settings.symbol);
  const end = Math.floor(Date.now() / BAR_MS) * BAR_MS;
  const start = end - (QUIET_BARS + REPLAY_BARS) * BAR_MS;
  let seed = 2166136261;
  const stamp = `${input.login}|${input.server}|${input.settings.symbol}|${end}`;
  for (let i = 0; i < stamp.length; i++) {
    seed ^= stamp.charCodeAt(i);
    seed = Math.imul(seed, 16777619);
  }
  let session: Session = {
    login: input.login.trim(),
    server: input.server.trim(),
    startBalance: input.startBalance,
    settings: input.settings,
    armed: true,
    speed: input.speed ?? "fast",
    rng: seed >>> 0,
    bars: [{ t: start, o: spec.start, h: spec.start, l: spec.start, c: spec.start }],
    cash: input.startBalance,
    position: null,
    trades: [],
    dayKey: dayKeyOf(start),
    dayRealized: 0,
    haltNoted: false,
    notes: [],
    equityPoints: [{ t: start, v: input.startBalance }],
    nextId: 1,
  };
  for (let i = 0; i < QUIET_BARS; i++) session = quiet(session);
  for (let i = 0; i < REPLAY_BARS; i++) session = step(session);
  return {
    ...session,
    notes: [
      {
        id: session.nextId,
        t: session.bars[session.bars.length - 1].t,
        text: "Robot armed on the paper book. Tape is simulated, not your broker feed.",
      },
      ...session.notes,
    ].slice(0, 12),
    nextId: session.nextId + 1,
    armed: true,
  };
}

export function flatten(session: Session): Session {
  if (!session.position) return session;
  const spec = specOf(session.settings.symbol);
  const last = session.bars[session.bars.length - 1];
  const exit = session.position.side === "buy" ? last.c - spec.spread / 2 : last.c + spec.spread / 2;
  return appendPoint(closeAt(session, exit, "flat", last.t, spec), spec);
}

export function snapshot(session: Session) {
  const spec = specOf(session.settings.symbol);
  const last = session.bars[session.bars.length - 1];
  const feat = features(session.bars);
  const pUp = feat ? probability(feat) : 0.5;
  const floating = session.position ? pnlAt(session.position, last.c, spec) : 0;
  const equity = session.cash + floating;
  const wins = session.trades.filter((t) => t.pnl > 0).length;
  const locked = session.dayRealized < -session.settings.maxDailyLoss * session.cash;
  const min = session.settings.minConfidence;
  const call: "buy" | "sell" | "wait" | "halt" = locked
    ? "halt"
    : pUp >= min
      ? "buy"
      : pUp <= 1 - min
        ? "sell"
        : "wait";
  return { spec, last, feat, pUp, floating, equity, wins, locked, call };
}

function pyString(value: string) {
  return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r?\n/g, " ");
}

export function robotScript(session: Session) {
  const s = session.settings;
  const login = Number(session.login);
  return `"""
ARC bot MT5 robot
Paper-tested on the ARC bot desk for account ${session.login} (${pyString(session.server)}).
Requirements (Windows, MT5 terminal installed and logged in):
    pip install MetaTrader5 pandas numpy scikit-learn
The password stays in the MetaTrader terminal. This script never asks for it.
"""
import time
import numpy as np
import pandas as pd
import MetaTrader5 as mt5
from sklearn.ensemble import GradientBoostingClassifier

SYMBOL = "${s.symbol}"
EXPECTED_LOGIN = ${Number.isFinite(login) ? login : 0}
EXPECTED_SERVER = "${pyString(session.server)}"
ALLOW_LIVE = ${s.liveProfile ? "True" : "False"}
TIMEFRAME = mt5.TIMEFRAME_M15
BARS = 5000
RISK_PER_TRADE = ${s.risk.toFixed(4)}
MAX_DAILY_LOSS = ${s.maxDailyLoss.toFixed(4)}
MIN_CONFIDENCE = ${s.minConfidence.toFixed(2)}
SL_ATR, TP_ATR = ${s.slAtr.toFixed(2)}, ${s.tpAtr.toFixed(2)}
MAGIC = 202611
RETRAIN_EVERY_SEC = 6 * 3600


def connect():
    if not mt5.initialize():
        raise SystemExit(f"MT5 init failed: {mt5.last_error()}")
    if not mt5.symbol_select(SYMBOL, True):
        raise SystemExit(f"Symbol not available: {SYMBOL}")
    acc = mt5.account_info()
    if acc is None:
        raise SystemExit("No account info. Log into the terminal first.")
    print(f"Connected: {acc.login} | {acc.server} | balance {acc.balance}")
    if acc.login != EXPECTED_LOGIN:
        raise SystemExit(
            f"Wrong account. Terminal is {acc.login}, robot expects {EXPECTED_LOGIN}."
        )
    if acc.server != EXPECTED_SERVER:
        print(f"Note: terminal server is {acc.server}, desk saved {EXPECTED_SERVER}.")
    demo = acc.trade_mode == 0
    if not demo and not ALLOW_LIVE:
        raise SystemExit("Terminal is not a demo account. Arm a demo, or opt in on the desk.")


def get_data(n=BARS):
    rates = mt5.copy_rates_from_pos(SYMBOL, TIMEFRAME, 0, n)
    if rates is None or len(rates) == 0:
        raise RuntimeError(f"No rates: {mt5.last_error()}")
    df = pd.DataFrame(rates)
    df["time"] = pd.to_datetime(df["time"], unit="s")
    return df


def add_features(df):
    d = df.copy()
    d["ret1"] = d["close"].pct_change()
    d["ret5"] = d["close"].pct_change(5)
    d["ret20"] = d["close"].pct_change(20)
    d["sma_ratio"] = d["close"].rolling(10).mean() / d["close"].rolling(50).mean()
    delta = d["close"].diff()
    gain = delta.clip(lower=0).rolling(14).mean()
    loss = (-delta.clip(upper=0)).rolling(14).mean()
    d["rsi"] = 100 - 100 / (1 + gain / (loss + 1e-12))
    tr = pd.concat(
        [
            d["high"] - d["low"],
            (d["high"] - d["close"].shift()).abs(),
            (d["low"] - d["close"].shift()).abs(),
        ],
        axis=1,
    ).max(axis=1)
    d["atr"] = tr.rolling(14).mean()
    d["vol"] = d["ret1"].rolling(20).std()
    d["hour"] = d["time"].dt.hour
    return d


FEATURES = ["ret1", "ret5", "ret20", "sma_ratio", "rsi", "vol", "hour"]


def train_model():
    d = add_features(get_data())
    d["target"] = (d["close"].shift(-5) > d["close"]).astype(int)
    d = d.dropna()
    split = int(len(d) * 0.8)
    train, test = d.iloc[:split], d.iloc[split:-5]
    model = GradientBoostingClassifier(n_estimators=150, max_depth=3, learning_rate=0.05)
    model.fit(train[FEATURES], train["target"])
    acc = (model.predict(test[FEATURES]) == test["target"]).mean()
    print(f"Model trained. Out-of-sample accuracy: {acc:.2%} (needs to be clearly >50%)")
    return model


def daily_loss_hit():
    start = pd.Timestamp.now().normalize().to_pydatetime()
    deals = mt5.history_deals_get(start, pd.Timestamp.now().to_pydatetime())
    pnl = sum(x.profit for x in deals if x.magic == MAGIC) if deals else 0
    return pnl < -MAX_DAILY_LOSS * mt5.account_info().balance


def lot_size(sl_distance):
    info = mt5.symbol_info(SYMBOL)
    risk_money = mt5.account_info().balance * RISK_PER_TRADE
    ticks = sl_distance / info.trade_tick_size
    lots = risk_money / (ticks * info.trade_tick_value)
    step = info.volume_step
    lots = max(info.volume_min, min(info.volume_max, round(lots / step) * step))
    return round(lots, 2)


def has_position():
    pos = mt5.positions_get(symbol=SYMBOL)
    return bool(pos and any(p.magic == MAGIC for p in pos))


def send_order(direction, atr):
    tick = mt5.symbol_info_tick(SYMBOL)
    buy = direction == 1
    price = tick.ask if buy else tick.bid
    sl_d, tp_d = atr * SL_ATR, atr * TP_ATR
    req = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": SYMBOL,
        "volume": lot_size(sl_d),
        "type": mt5.ORDER_TYPE_BUY if buy else mt5.ORDER_TYPE_SELL,
        "price": price,
        "sl": price - sl_d if buy else price + sl_d,
        "tp": price + tp_d if buy else price - tp_d,
        "deviation": 20,
        "magic": MAGIC,
        "comment": "ARC bot ML",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }
    fillings = [mt5.ORDER_FILLING_IOC, mt5.ORDER_FILLING_FOK, mt5.ORDER_FILLING_RETURN]
    res = None
    for fill in fillings:
        req["type_filling"] = fill
        res = mt5.order_send(req)
        if res is None:
            continue
        if res.retcode == mt5.TRADE_RETCODE_DONE:
            break
        if res.retcode != 10030:
            break
    print("Order:", "BUY" if buy else "SELL", None if res is None else res.retcode, None if res is None else res.comment)


def run():
    connect()
    model = train_model()
    last_train = time.time()
    last_bar = None
    while True:
        try:
            if time.time() - last_train > RETRAIN_EVERY_SEC:
                model = train_model()
                last_train = time.time()
            d = add_features(get_data(200)).dropna()
            bar_time = d["time"].iloc[-2]
            if bar_time != last_bar:
                last_bar = bar_time
                if daily_loss_hit():
                    print("Daily loss limit hit - no trading today.")
                elif not has_position():
                    row = d.iloc[[-2]]
                    p_up = model.predict_proba(row[FEATURES])[0][1]
                    atr = float(row["atr"].iloc[0])
                    if p_up >= MIN_CONFIDENCE:
                        send_order(1, atr)
                    elif p_up <= 1 - MIN_CONFIDENCE:
                        send_order(-1, atr)
            time.sleep(10)
        except Exception as e:
            print("Error:", e)
            time.sleep(30)


if __name__ == "__main__":
    run()
`;
}
