package app.arcbot;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setStatusBarColor(Color.parseColor("#F4F6FB"));
        window.setNavigationBarColor(Color.parseColor("#F4F6FB"));
        int flags = window.getDecorView().getSystemUiVisibility();
        flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        window.getDecorView().setSystemUiVisibility(flags);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#F4F6FB"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Bridge(), "ArcNative");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Stay inside the bundled app; never navigate away.
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
    }

    private static final Set<String> ALLOWED_HOSTS = new HashSet<>(Arrays.asList(
            "data-api.binance.vision", "api.binance.com",
            "query1.finance.yahoo.com", "query2.finance.yahoo.com",
            "bsc-dataseed.binance.org", "bsc-dataseed1.defibit.io", "bsc-rpc.publicnode.com"));

    private class Bridge {
        // Native HTTP so price feeds and the BSC check are not limited by browser CORS rules.
        @JavascriptInterface
        public void http(final int id, final String method, final String url, final String body) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    int status = 0;
                    byte[] data = new byte[0];
                    try {
                        Uri u = Uri.parse(url);
                        if (!"https".equals(u.getScheme()) || !ALLOWED_HOSTS.contains(u.getHost())) {
                            throw new java.io.IOException("blocked");
                        }
                        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                        c.setConnectTimeout(8000);
                        c.setReadTimeout(10000);
                        c.setRequestMethod("POST".equals(method) ? "POST" : "GET");
                        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) ARCbot/1.2");
                        c.setRequestProperty("Accept", "application/json");
                        if ("POST".equals(method)) {
                            c.setDoOutput(true);
                            c.setRequestProperty("Content-Type", "application/json");
                            OutputStream os = c.getOutputStream();
                            os.write(body.getBytes("UTF-8"));
                            os.close();
                        }
                        status = c.getResponseCode();
                        InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                        if (in != null) {
                            ByteArrayOutputStream bo = new ByteArrayOutputStream();
                            byte[] buf = new byte[8192];
                            int n;
                            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                            in.close();
                            data = bo.toByteArray();
                        }
                    } catch (Exception e) {
                        status = 0;
                    }
                    final String b64 = Base64.encodeToString(data, Base64.NO_WRAP);
                    final int st = status;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (web != null) {
                                web.evaluateJavascript("window.__arcHttp(" + id + "," + st + ",\"" + b64 + "\")", null);
                            }
                        }
                    });
                }
            }).start();
        }

        @JavascriptInterface
        public void copy(String text) {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("ARC bot profile", text));
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
