# ARC bot

Paper-trading desk for an MT5-style ML robot. Offline, no accounts, no external services.

## Get the APK (pick one)

**A. GitHub (no installs):** create a new repo, upload everything in this folder, open the
*Actions* tab, run **Build ARC bot APK**, download the `ARC-bot-apk` artifact (`app-release.apk`).

**B. Android Studio:** open the `android/` folder, wait for Gradle sync,
then *Build > Build Bundle(s) / APK(s) > Build APK(s)*.
(Or, with Gradle 8.7 + JDK 17 + Android SDK 34: `cd android && gradle assembleRelease`.)

Install on your phone: copy the APK over and allow "Install unknown apps".

## Layout
- `web/index.html` – the full app (single file, also runs in any browser)
- `android/` – WebView wrapper that bundles `web/index.html` as `assets/index.html`
- `store-icon-512.png` – icon

## Notes
- The bundled `arcbot.keystore` is a sideload key. Make your own before publishing to Google Play.
- Prices are live: Binance (crypto, 24/7) and Yahoo Finance (forex and metals, can lag slightly and pause on weekends). The robot paper-trades on them. It never places broker orders or asks for a password.
